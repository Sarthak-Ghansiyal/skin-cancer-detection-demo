# Skin Cancer Detection AI – SehatSaathi Demo

This is a Streamlit-powered web app that detects skin cancer (benign or malignant) using a trained TensorFlow model.

## Demo Preview

![Skin Cancer Detection Demo](demo_screenshot.png)

## Features
- Upload lesion images
- AI predicts cancer risk
- Displays confidence and warning
